#### Friend Link Server v0.1 ####
The sever behind friend link. 

#### Installing ####
The server uses two ports to communicate with the clients. One uses TCP/UDP and the other UDP.
The default ports are:
TCP/UDP port: 29015
UDP port: 29016
These ports do not support NAT and you will need to forward them manually.

#### Configuration ####
If you want to use a custom configuration then you can set different settings in the command line.
To see what the settings are run server /?, which will produce:
Usage: FriendLinkServer [option(s)]
	Options:
    		-h,--help,/?			Show this help message.
    		-n,--name "server name"		Sets the server name.
    		-mp,--max_players [0-255]	Sets the max number of players allowed on the server.
    		-p1,--port1 port		Sets port the server(tcp) and client(udp) will listen on.
    		-p2,--port2 port		Sets port the server(udp) will listen on.
