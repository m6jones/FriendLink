#### Friend Link Client v0.1 ####
A Skyrim mod that allows you to appear in other Skyrim worlds as a ball of energy allowing you to share the Skyrim 
experience with friends. This mod does not synchronize Skyrim games but simply allows you to show up as a ball of energy 
in other games. 

#### Requires ####
Skyrim
SKSE - build 1.7.3 - http://skse.silverlock.org/
ScriptDragon build - v1.9.32.0 - http://www.dev-c.com/skyrim/scriptdragon/

#### Installing ####
1. Have all the requirements installed.
2. Move everything from the zip to your skyrim folder where TESV.exe is located.
	Files in zip				|  Location on your system
	---------------------------------------------------------------------
	FriendLinkIP.cfg 			-> <location of skyrim>/Skyrim
	Make FriendLink asi link.bat 		-> <location of skyrim>/Skyrim
	Data/FriendLink.bsa			-> <location of skyrim>/Skyrim/Data
	Data/FriendLink.bsl			-> <location of skyrim>/Skyrim/Data
	Data/FriendLink.esp			-> <location of skyrim>/Skyrim/Data
	Data/Script/FriendLinkScript.pex	-> <location of skyrim>/Skyrim/Data/Script
	Data/SKSE/Plugins/FriendLink.dll	-> <location of skyrim>/Skyrim/Data/Data/SKSE/Plugins
3. Run Make FriendLink asi link.bat as administrator. 
   This will make a file called FriendLink.asi in <location of skyrim>/Skyrim folder.
   FriendLink.asi is a soft symbolic link of FriendLink.dll which gives the functions from dragon script.
4. Open up FriendLinkIP.cfg with notepad. This information should be gather by the server administrator.
   The first line is the IP of the server. 
   The second line is the same port as -port1 on the server. Default: 29015. This port requires to be forwarded as UDP protocal.
   The third line is the same as -port2 on the server. Default: 29016.
5. Forward the -port1 from the the previous step.
6. Select Friendlink.esp to be loaded by skyrim.

#### Running the client ####
1. Start Skryim and load into a character. You should see the message, "Friend Link script launched". If you don't not see step 3 of installation.
2. Go to the Sleeping Giant Inn in Riverwood.
3. This should start a quest and give you the spell FriendLink Connect.
4. Cast FriendLink Connect (will not be seen as aggressive to npcs). You will connect to the server described by FriendLinkIP.cfg.
5. To disconnect from the server cast the disconnect spell or exit the game.
	
